const divs = document.querySelectorAll('.forum-middle')

const images = {
  ':tf:': 'https://cdn.betterttv.net/emote/54fa8f1401e468494b85b537/3x.webp',
  CiGrip: 'https://cdn.betterttv.net/emote/54fa8fce01e468494b85b53c/3x.webp',
  DatSauce: 'https://cdn.betterttv.net/emote/54fa903b01e468494b85b53f/3x.webp',
  ForeverAlone:
    'https://cdn.betterttv.net/emote/54fa909b01e468494b85b542/3x.webp',
  GabeN: 'https://cdn.betterttv.net/emote/54fa90ba01e468494b85b543/3x.webp',
  HailHelix: 'https://cdn.betterttv.net/emote/54fa90f201e468494b85b545/3x.webp',
  ShoopDaWhoop:
    'https://cdn.betterttv.net/emote/54fa932201e468494b85b555/3x.webp',
  'M&Mjc': 'https://cdn.betterttv.net/emote/54fab45f633595ca4c713abc/3x.webp',
  bttvNice: 'https://cdn.betterttv.net/emote/54fab7d2633595ca4c713abf/3x.webp',
  TwaT: 'https://cdn.betterttv.net/emote/54fa935601e468494b85b557/3x.webp',
  WatChuSay: 'https://cdn.betterttv.net/emote/54fa99b601e468494b85b55d/3x.webp',
  tehPoleCat:
    'https://cdn.betterttv.net/emote/566ca11a65dbbdab32ec0558/3x.webp',
  AngelThump:
    'https://cdn.betterttv.net/emote/566ca1a365dbbdab32ec055b/3x.webp',
  TaxiBro: 'https://cdn.betterttv.net/emote/54fbefeb01abde735115de5b/3x.webp',
  BroBalt: 'https://cdn.betterttv.net/emote/54fbf00a01abde735115de5c/3x.webp',
  CandianRage:
    'https://cdn.betterttv.net/emote/54fbf09c01abde735115de61/3x.webp',
  'D:': 'https://cdn.betterttv.net/emote/55028cd2135896936880fdd7/3x.webp',
  VisLaud: 'https://cdn.betterttv.net/emote/550352766f86a5b26c281ba2/3x.webp',
  KaRappa: 'https://cdn.betterttv.net/emote/550b344bff8ecee922d2a3c1/3x.webp',
  FishMoley: 'https://cdn.betterttv.net/emote/566ca00f65dbbdab32ec0544/3x.webp',
  Hhhehehe: 'https://cdn.betterttv.net/emote/566ca02865dbbdab32ec0547/3x.webp',
  KKona: 'https://cdn.betterttv.net/emote/566ca04265dbbdab32ec054a/3x.webp',
  PoleDoge: 'https://cdn.betterttv.net/emote/566ca09365dbbdab32ec0555/3x.webp',
  sosGame: 'https://cdn.betterttv.net/emote/553b48a21f145f087fc15ca6/3x.webp',
  CruW: 'https://cdn.betterttv.net/emote/55471c2789d53f2d12781713/3x.webp',
  RarePepe: 'https://cdn.betterttv.net/emote/555015b77676617e17dd2e8e/3x.webp',
  haHAA: 'https://cdn.betterttv.net/emote/555981336ba1901877765555/3x.webp',
  FeelsBirthdayMan:
    'https://cdn.betterttv.net/emote/55b6524154eefd53777b2580/3x.webp',
  RonSmug: 'https://cdn.betterttv.net/emote/55f324c47f08be9f0a63cce0/3x.webp',
  KappaCool: 'https://cdn.betterttv.net/emote/560577560874de34757d2dc0/3x.webp',
  FeelsBadMan:
    'https://cdn.betterttv.net/emote/566c9fc265dbbdab32ec053b/3x.webp',
  bUrself: 'https://cdn.betterttv.net/emote/566c9f3b65dbbdab32ec052e/3x.webp',
  ConcernDoge:
    'https://cdn.betterttv.net/emote/566c9f6365dbbdab32ec0532/3x.webp',
  FeelsGoodMan:
    'https://cdn.betterttv.net/emote/566c9fde65dbbdab32ec053e/3x.webp',
  FireSpeed: 'https://cdn.betterttv.net/emote/566c9ff365dbbdab32ec0541/3x.webp',
  NaM: 'https://cdn.betterttv.net/emote/566ca06065dbbdab32ec054e/3x.webp',
  SourPls: 'https://cdn.betterttv.net/emote/566ca38765dbbdab32ec0560/3x.webp',
  FeelsSnowMan:
    'https://cdn.betterttv.net/emote/566dde0e65dbbdab32ec068f/3x.webp',
  FeelsSnowyMan:
    'https://cdn.betterttv.net/emote/566decae65dbbdab32ec0699/3x.webp',
  LUL: 'https://cdn.betterttv.net/emote/567b00c61ddbe1786688a633/3x.webp',
  SaltyCorn: 'https://cdn.betterttv.net/emote/56901914991f200c34ffa656/3x.webp',
  monkaS: 'https://cdn.betterttv.net/emote/56e9f494fff3cc5c35e5287e/3x.webp',
  VapeNation:
    'https://cdn.betterttv.net/emote/56f5be00d48006ba34f530a4/3x.webp',
  ariW: 'https://cdn.betterttv.net/emote/56fa09f18eff3b595e93ac26/3x.webp',
  notsquishY:
    'https://cdn.betterttv.net/emote/5709ab688eff3b595e93c595/3x.webp',
  FeelsAmazingMan:
    'https://cdn.betterttv.net/emote/5733ff12e72c3c0814233e20/3x.webp',
  DuckerZ: 'https://cdn.betterttv.net/emote/573d38b50ffbf6cc5cc38dc9/3x.webp',
  SqShy: 'https://cdn.betterttv.net/emote/59cf182fcbe2693d59d7bf46/3x.webp',
  Wowee: 'https://cdn.betterttv.net/emote/58d2e73058d8950a875ad027/3x.webp',
  WubTF: 'https://cdn.betterttv.net/emote/5dc36a8db537d747e37ac187/3x.webp',
  cvR: 'https://cdn.betterttv.net/emote/5e76d2ab8c0f5c3723a9a87d/3x.webp',
  cvL: 'https://cdn.betterttv.net/emote/5e76d2d2d112fc372574d222/3x.webp',
  cvHazmat: 'https://cdn.betterttv.net/emote/5e76d338d6581c3724c0f0b2/3x.webp',
  cvMask: 'https://cdn.betterttv.net/emote/5e76d399d6581c3724c0f0b8/3x.webp',
  KEKW: 'https://cdn.betterttv.net/emote/5e9c6c187e090362f8b0b9e8/3x.webp',
  LULW: 'https://cdn.betterttv.net/emote/5dc79d1b27360247dd6516ec/3x.webp',
  monkaW: 'https://cdn.betterttv.net/emote/59ca6551b27c823d5b1fd872/3x.webp',
  PogU: 'https://cdn.betterttv.net/emote/5e4e7a1f08b4447d56a92967/3x.webp',
  PogChamp: 'https://cdn.betterttv.net/emote/60241a5f119bd217d848368e/3x.webp',
  WeirdChamp:
    'https://cdn.betterttv.net/emote/5d9198fbd2458468c1f4adb7/3x.webp',
  OMEGALUL: 'https://cdn.betterttv.net/emote/583089f4737a8e61abb0186b/3x.webp',
  Kappa: 'https://cdn.betterttv.net/emote/5d3e0e1236c0c02aeb6d2b30/3x.webp',
  NOMEGALUL: 'https://cdn.betterttv.net/emote/5c56fe8839bfc5202398645c/3x.webp',
  DogChamp: 'https://cdn.betterttv.net/emote/5ffdf28dc96152314ad63960/3x.webp',
  catJAM: 'https://cdn.betterttv.net/emote/5f1b0186cf6d2144653d2970/3x.webp',
  KEKWait: 'https://betterttv.com/emotes/5e486af4d736527d5cd2fed6'
}

divs.forEach(div => {
  Object.keys(images).map(key => {
    div.innerHTML = div.innerHTML.replaceAll(
      key,
      `<img src="${images[key]}" width="25rem" />`
    )
  })
})
